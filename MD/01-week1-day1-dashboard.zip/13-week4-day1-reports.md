# Week 4 - Day 1: Rapor Sayfaları

## Hedef Dosyalar
`frontend/src/pages/reports/*.vue`

## Rapor Sayfası Pattern

```html
<div class="page-shell">
  <div class="detail-topbar">
    <div>
      <p class="detail-breadcrumb">Raporlar</p>
      <h1 class="detail-title">{{ reportTitle }}</h1>
    </div>
    <div class="flex gap-2">
      <button class="btn btn-outline btn-sm"><IconDownload /> Excel</button>
      <button class="btn btn-outline btn-sm"><IconPrinter /> Yazdır</button>
    </div>
  </div>

  <!-- Filters -->
  <DetailCard title="Filtreler" collapsible>
    <div class="form-grid">
      <div class="form-field">
        <label class="form-label">Tarih Aralığı</label>
        <input type="date" class="form-input" />
      </div>
    </div>
    <div class="mt-4 flex justify-end">
      <button class="btn btn-primary btn-sm">Raporu Getir</button>
    </div>
  </DetailCard>

  <!-- Summary Metrics -->
  <div class="grid grid-cols-4 gap-4 mb-6">
    <div class="mini-metric">...</div>
  </div>

  <!-- Chart or Table -->
  <DetailCard title="Detay">
    <div class="chart-container">
      <!-- Chart.js veya tablo -->
    </div>
  </DetailCard>
</div>
```

## Chart Container CSS
```css
.chart-container { @apply relative h-64 md:h-80; }
```
