# Acentem Takipte - Design System Migration Prompts

Bu klasör, Acentem Takipte uygulamasının tamamını tutarlı tasarım sistemine geçirmek için VSCode Agent'a verilebilecek prompt'ları içerir.

## Kullanım

Her dosya bir gün/sayfa için hazırlanmış detaylı bir prompt içerir. Dosyaları sırayla VSCode Agent'a vererek tasarım sistemi dönüşümünü gerçekleştirebilirsiniz.

## Dosya Yapısı

### Hafta 1: Ana Sayfalar (Liste Görünümleri)
- `01-week1-day1-dashboard.md` - Dashboard / Ana Sayfa
- `02-week1-day2-policies-list.md` - Poliçe Listesi
- `03-week1-day3-offers-list.md` - Teklif Listesi  
- `04-week1-day4-customers-list.md` - Müşteri Listesi (Card Grid + Table)

### Hafta 2: Detay Sayfaları
- `05-week2-day1-offer-detail.md` - Teklif Detay Sayfası
- `06-week2-day2-claim-detail.md` - Hasar Detay Sayfası
- `07-week2-day3-renewal-detail.md` - Yenileme Görevi Detay
- `08-week2-day4-payment-detail.md` - Ödeme Detay Sayfası

### Hafta 3: Formlar ve Dialoglar
- `09-week3-day1-policy-form.md` - Poliçe Oluşturma/Düzenleme Formu
- `10-week3-day2-quick-create-dialogs.md` - Hızlı Oluşturma Dialog'ları
- `11-week3-day3-edit-modals.md` - Düzenleme Modal'ları
- `12-week3-day4-import-export.md` - İçe/Dışa Aktarma Ekranları

### Hafta 4: Raporlar ve Özel Ekranlar
- `13-week4-day1-reports.md` - Rapor Sayfaları
- `14-week4-day2-renewals-board.md` - Yenileme Tahtası (Kanban)
- `15-week4-day3-analytics.md` - Analitik Dashboard'lar
- `16-week4-day4-cleanup.md` - Son Temizlik ve Optimizasyon

## Önkoşullar

Başlamadan önce şu dosyaların mevcut ve güncel olduğundan emin olun:

1. `tailwind.config.js` - Brand ve status renk token'ları
2. `src/assets/design-system.css` - Tüm utility class'lar
3. `src/components/ui/` - Temel UI komponentleri:
   - `StatusBadge.vue`
   - `HeroStrip.vue`
   - `DetailCard.vue`
   - `FieldGroup.vue`
   - `StepBar.vue`

## İlerleme Takibi

Her dosyayı tamamladıktan sonra işaretleyin:

- [ ] 01 - Dashboard
- [ ] 02 - Poliçe Listesi
- [ ] 03 - Teklif Listesi
- [ ] 04 - Müşteri Listesi
- [ ] 05 - Teklif Detay
- [ ] 06 - Hasar Detay
- [ ] 07 - Yenileme Detay
- [ ] 08 - Ödeme Detay
- [ ] 09 - Poliçe Formu
- [ ] 10 - Quick Create
- [ ] 11 - Edit Modals
- [ ] 12 - Import/Export
- [ ] 13 - Raporlar
- [ ] 14 - Renewals Board
- [ ] 15 - Analytics
- [ ] 16 - Cleanup

## Audit Script

Migrasyon durumunu kontrol etmek için:

```bash
node scripts/audit-design-system.js
```

## Notlar

- Her prompt mevcut iş mantığını korur, sadece UI/UX'i günceller
- API çağrıları ve store kullanımı değiştirilmez
- Responsive tasarım tüm ekranlarda test edilmelidir
- Her değişiklik sonrası dosyayı kaydedin ve test edin
