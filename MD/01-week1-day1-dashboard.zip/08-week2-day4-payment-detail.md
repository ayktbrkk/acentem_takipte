# Week 2 - Day 4: Ödeme Detay Sayfası

## Hedef Dosya
`frontend/src/pages/PaymentDetail.vue`

## HeroStrip
```js
const heroCells = computed(() => [
  { label: 'Ödeme No', value: payment.value?.payment_no, variant: 'default' },
  { label: 'Vade Tarihi', value: formatDate(payment.value?.due_date), variant: 'default' },
  { label: 'Tutar', value: formatCurrency(payment.value?.amount), variant: 'lg' },
  { label: 'Durum', value: payment.value?.status, variant: 'accent' },
])
```

## Ana Kolon
1. Ödeme Bilgileri (DetailCard)
2. İlgili Poliçe (DetailCard + Link)
3. Tahsilat Geçmişi (DetailCard + Table)
4. Dekont/Fatura (DetailCard + Upload)

## Sidebar
1. Müşteri Bilgisi
2. Ödeme Detayları
3. Muhasebe Kodu
4. Kayıt Meta

**Teklif detay pattern'ini takip et.**
