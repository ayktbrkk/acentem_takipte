# Week 3 - Day 3: Düzenleme Modal'ları

## Hedef Dosyalar
Tüm edit modal komponentleri

## Pattern
Quick Create dialog pattern'ini kullan, sadece başlık "Düzenle" olacak.
Pre-populate form fields with existing data.

```js
onMounted(() => {
  if (props.itemId) {
    loadExistingData(props.itemId)
  }
})
```

## Validation
```html
<input :class="['form-input', errors.field && 'error']" />
<p v-if="errors.field" class="form-error">{{ errors.field }}</p>
```

```css
.form-input.error { @apply border-red-300 focus:ring-red-500; }
.form-error { @apply text-sm text-red-600 mt-1; }
```
