# Week 2 - Day 3: Yenileme Görevi Detay

## Hedef Dosya
`frontend/src/pages/RenewalTaskDetail.vue`

## StepBar
```js
const renewalSteps = computed(() => [
  { label: 'Bildirim', status: getStepStatus('notified') },
  { label: 'Teklif', status: getStepStatus('offer_sent') },
  { label: 'Karar', status: getStepStatus('decision') },
  { label: 'Poliçe', status: getStepStatus('renewed') },
])
```

## Priority Badge
```html
<span :class="[
  'badge',
  renewal.priority === 'high' && 'badge-red',
  renewal.priority === 'medium' && 'badge-amber',
  renewal.priority === 'low' && 'badge-gray',
]">
  {{ priorityLabel(renewal.priority) }}
</span>
```

## Ana Kolon
1. Eski Poliçe Bilgileri (DetailCard)
2. Yeni Teklifler (DetailCard + Liste)
3. Müşteri İletişim Geçmişi (Timeline)
4. Hatırlatıcılar (DetailCard)

**Müşteri detay pattern'ini kullan.**
