# Week 1 - Day 1: Dashboard Tasarım Sistemi Geçişi

## Hedef Dosya
`frontend/src/pages/Dashboard.vue` (veya `Home.vue`, `Index.vue`)

## Görev
Ana dashboard'u design system'e çevir. Mevcut iş mantığını koruyarak sadece template ve stilleri güncelle.

## Design Tokens
- Metric kartları: `mini-metric` veya `DetailCard` kullan
- Grafik container'ları: `DetailCard` ile sarmala
- Hızlı eylem butonları: `btn btn-primary`, `btn btn-outline` kullan
- Grid layout: `grid grid-cols-1 lg:grid-cols-3 gap-4` yapısı

## Beklenen Yapı

```html
<div class="page-shell">
  <!-- Topbar -->
  <div class="detail-topbar">
    <div>
      <h1 class="detail-title">Dashboard</h1>
      <p class="text-sm text-gray-500">Hoş geldiniz, {{ userName }}</p>
    </div>
    <div class="flex gap-2">
      <button class="btn btn-outline btn-sm">
        <IconRefresh /> Yenile
      </button>
      <button class="btn btn-primary btn-sm">
        + Yeni İşlem
      </button>
    </div>
  </div>

  <!-- Hero Stats -->
  <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
    <div class="mini-metric">
      <p class="mini-metric-label">Aktif Poliçeler</p>
      <p class="mini-metric-value text-brand-600">{{ stats.activePolicies }}</p>
    </div>
    <div class="mini-metric">
      <p class="mini-metric-label">Bekleyen Teklifler</p>
      <p class="mini-metric-value text-amber-600">{{ stats.pendingOffers }}</p>
    </div>
    <div class="mini-metric">
      <p class="mini-metric-label">Açık Hasarlar</p>
      <p class="mini-metric-value text-red-600">{{ stats.openClaims }}</p>
    </div>
    <div class="mini-metric">
      <p class="mini-metric-label">Aylık Prim</p>
      <p class="mini-metric-value text-green-600">{{ formatCurrency(stats.monthlyPremium) }}</p>
    </div>
  </div>

  <!-- Ana İçerik -->
  <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <!-- Sol kolon: Son aktiviteler -->
    <div class="lg:col-span-2">
      <DetailCard title="Son Aktiviteler">
        <template #action>
          <button class="btn btn-sm">Tümünü Gör</button>
        </template>
        
        <div v-if="!activities?.length" class="card-empty">
          Henüz aktivite kaydı yok.
        </div>
        <div v-else class="space-y-3">
          <div
            v-for="activity in activities"
            :key="activity.name"
            class="timeline-item"
          >
            <div :class="['tl-dot', activity.is_important && 'tl-dot-active']" />
            <div>
              <p class="tl-text">{{ activity.description }}</p>
              <p class="tl-time">{{ formatDate(activity.creation) }} · {{ activity.owner }}</p>
            </div>
          </div>
        </div>
      </DetailCard>

      <!-- Grafikler -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
        <DetailCard title="Aylık Prim Trendi">
          <div class="chart-container">
            <!-- Chart.js veya başka grafik kütüphanesi -->
          </div>
        </DetailCard>
        
        <DetailCard title="Branş Dağılımı">
          <div class="chart-container">
            <!-- Pie chart -->
          </div>
        </DetailCard>
      </div>
    </div>

    <!-- Sağ kolon: Hızlı işlemler ve bildirimler -->
    <div class="space-y-4">
      <DetailCard title="Hızlı İşlemler">
        <div class="space-y-2">
          <button class="w-full btn btn-outline justify-start">
            <IconPlus /> Yeni Poliçe
          </button>
          <button class="w-full btn btn-outline justify-start">
            <IconFileText /> Yeni Teklif
          </button>
          <button class="w-full btn btn-outline justify-start">
            <IconUsers /> Yeni Müşteri
          </button>
          <button class="w-full btn btn-outline justify-start">
            <IconAlertCircle /> Hasar Bildirimi
          </button>
        </div>
      </DetailCard>

      <DetailCard title="Bugün Yapılacaklar">
        <template #action>
          <span class="badge badge-blue">{{ todayTasks?.length || 0 }}</span>
        </template>
        
        <div v-if="!todayTasks?.length" class="card-empty">
          Bugün için görev yok.
        </div>
        <div v-else class="space-y-2">
          <div
            v-for="task in todayTasks"
            :key="task.name"
            class="flex items-start gap-2 p-2 rounded-md hover:bg-gray-50"
          >
            <input type="checkbox" class="mt-1" />
            <div class="flex-1">
              <p class="text-sm text-gray-900">{{ task.title }}</p>
              <p class="text-xs text-gray-500">{{ task.due_date }}</p>
            </div>
          </div>
        </div>
      </DetailCard>

      <DetailCard title="Yaklaşan Yenilemeler">
        <template #action>
          <span class="badge badge-amber">{{ upcomingRenewals?.length || 0 }}</span>
        </template>
        
        <div v-if="!upcomingRenewals?.length" class="card-empty">
          30 gün içinde yenileme yok.
        </div>
        <div v-else class="divide-y divide-gray-100">
          <div
            v-for="renewal in upcomingRenewals"
            :key="renewal.name"
            class="py-2"
          >
            <p class="text-sm font-medium text-gray-900">{{ renewal.customer_name }}</p>
            <p class="text-xs text-gray-500">{{ renewal.policy_branch }} · {{ formatDate(renewal.due_date) }}</p>
          </div>
        </div>
      </DetailCard>
    </div>
  </div>
</div>
```

## Script Setup Güncellemeleri

```js
import { ref, computed, onMounted } from 'vue'
import DetailCard from '@/components/ui/DetailCard.vue'

// Mevcut store ve composable'ları koru
// Sadece yeni komponentleri import et

// Chart container için yardımcı
const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
}

// Date formatter
function formatDate(date) {
  if (!date) return '—'
  return new Date(date).toLocaleDateString('tr-TR')
}

// Currency formatter
function formatCurrency(amount) {
  if (!amount) return '—'
  return new Intl.NumberFormat('tr-TR', {
    style: 'currency',
    currency: 'TRY'
  }).format(amount)
}
```

## CSS Eklemeleri (design-system.css)

```css
/* Chart Container */
.chart-container {
  @apply relative h-64 md:h-80;
}

/* Quick Action Buttons */
.btn.justify-start {
  @apply justify-start;
}
```

## Kontrol Listesi

- [ ] `page-shell` wrapper eklendi
- [ ] `detail-topbar` ile header oluşturuldu
- [ ] Metric kartları `mini-metric` class'ı kullanıyor
- [ ] `DetailCard` komponentleri import edilmiş
- [ ] Butonlar `btn` class'larını kullanıyor
- [ ] Timeline items `timeline-item` class'ı kullanıyor
- [ ] Empty state'ler `card-empty` class'ı kullanıyor
- [ ] Responsive grid yapısı düzgün çalışıyor
- [ ] Renk token'ları (`text-brand-600`, `text-amber-600`) kullanılıyor
- [ ] Loading state'ler için skeleton veya spinner var (opsiyonel)

## Test Adımları

1. Sayfayı tarayıcıda aç
2. Tüm metrikler doğru görünüyor mu?
3. Kartlar düzgün render ediliyor mu?
4. Responsive görünüm mobile'da düzgün mü?
5. Butonlar tıklanabilir ve çalışıyor mu?
6. Grafikler (varsa) düzgün render ediliyor mu?
