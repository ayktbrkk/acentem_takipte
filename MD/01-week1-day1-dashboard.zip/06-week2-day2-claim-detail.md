# Week 2 - Day 2: Hasar Detay Sayfası

## Hedef Dosya
`frontend/src/pages/ClaimDetail.vue`

## HeroStrip
```js
const heroCells = computed(() => [
  { label: 'Dosya No', value: claim.value?.claim_no, variant: 'default' },
  { label: 'Hasar Tarihi', value: formatDate(claim.value?.loss_date), variant: 'default' },
  { label: 'Rezerv', value: formatCurrency(claim.value?.reserve_amount), variant: 'lg' },
  { label: 'Ödenen', value: formatCurrency(claim.value?.paid_amount), variant: 'accent' },
])
```

## StepBar (Hasar Süreci)
```js
const claimSteps = computed(() => [
  { label: 'Bildirim', status: 'complete' },
  { label: 'Ekspertiz', status: currentStepIs('expertise') ? 'current' : 'complete' },
  { label: 'Onay', status: currentStepIs('approval') ? 'current' : 'pending' },
  { label: 'Ödeme', status: currentStepIs('payment') ? 'current' : 'pending' },
])
```

## Ana Kolon Sections
1. Hasar Bilgileri (DetailCard + FieldGroup)
2. İlgili Poliçe (DetailCard + Link)
3. Dökümanlar (DetailCard + Upload)
4. Ödeme Geçmişi (DetailCard + Table)
5. Notlar & Timeline (DetailCard)

## Sidebar
1. İlgili Kişiler (Eksper, Müşteri)
2. Durum Bilgisi
3. Kayıt Meta

**Detaylar için müşteri/teklif detay prompt'larını referans al.**
