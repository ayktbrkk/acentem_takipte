# Week 3 - Day 1: Poliçe Oluşturma/Düzenleme Formu

## Hedef Dosya
`frontend/src/components/PolicyForm.vue`

## Multi-Step Form Pattern

```html
<div class="form-shell">
  <div class="form-header">
    <h2>{{ isEdit ? 'Poliçe Düzenle' : 'Yeni Poliçe' }}</h2>
    <button class="btn-icon" @click="closeForm"><IconX /></button>
  </div>

  <StepBar :steps="formSteps" />

  <form @submit.prevent="handleSubmit" class="space-y-6">
    <!-- Step 1: Müşteri -->
    <div v-if="currentStep === 1" class="form-section">
      <h3 class="form-section-title">Müşteri Bilgileri</h3>
      <div class="form-grid">
        <div class="form-field">
          <label class="form-label required">Müşteri</label>
          <select v-model="form.customer" class="form-input" required>
            <option value="">Seçin...</option>
          </select>
        </div>
      </div>
    </div>

    <!-- Step 2: Poliçe Detayları -->
    <!-- Step 3: Teminatlar -->
    <!-- Step 4: Ödeme -->

    <div class="form-footer">
      <button v-if="currentStep > 1" type="button" class="btn btn-outline" @click="currentStep--">Geri</button>
      <button v-if="currentStep < totalSteps" type="button" class="btn btn-primary" @click="currentStep++">İleri</button>
      <button v-if="currentStep === totalSteps" type="submit" class="btn btn-primary">Kaydet</button>
    </div>
  </form>
</div>
```

## CSS (design-system.css)
```css
.form-shell { @apply bg-white rounded-lg shadow-lg max-w-4xl mx-auto; }
.form-header { @apply flex items-center justify-between p-6 border-b border-gray-200; }
.form-section { @apply p-6; }
.form-section-title { @apply text-base font-semibold text-gray-900 mb-4; }
.form-grid { @apply grid grid-cols-1 md:grid-cols-2 gap-4; }
.form-field { @apply space-y-1.5; }
.form-label { @apply block text-sm font-medium text-gray-700; }
.form-label.required::after { @apply text-red-500 ml-1; content: '*'; }
.form-input { @apply w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-brand-500; }
.form-footer { @apply px-6 py-4 bg-gray-50 border-t flex justify-end gap-3; }
```
