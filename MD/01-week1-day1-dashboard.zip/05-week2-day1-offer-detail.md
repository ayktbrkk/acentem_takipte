# Week 2 - Day 1: Teklif Detay Sayfası

## Hedef Dosya
`frontend/src/pages/OfferDetail.vue` (veya `TeklifDetay.vue`)

## Görev
Teklif detay sayfasını müşteri detay sayfası ile aynı design pattern'e çevir.

## Base Template
Müşteri detay prompt'undaki yapıyı kullan, şu değişikliklerle:

## HeroStrip Cells

```js
const heroCells = computed(() => [
  { label: 'Şirket', value: offer.value?.company_name || '—', variant: 'default' },
  { label: 'Branş', value: offer.value?.branch || '—', variant: 'default' },
  { label: 'Prim', value: formatCurrency(offer.value?.premium), variant: 'lg' },
  { label: 'Geçerlilik', value: formatDate(offer.value?.valid_until), variant: 'accent' },
])
```

## Topbar

```html
<div class="detail-topbar">
  <div>
    <p class="detail-breadcrumb">Teklifler</p>
    <h1 class="detail-title">
      {{ offer?.offer_no || 'Teklif Detayı' }}
      <StatusBadge :status="offer?.status?.toLowerCase()" />
    </h1>
    <div class="flex items-center gap-2 mt-1.5">
      <span class="copy-tag">{{ offer?.name }}</span>
      <span v-if="offer?.customer_name" class="text-sm text-gray-500">
        {{ offer.customer_name }}
      </span>
    </div>
  </div>
  <div class="flex items-center gap-2">
    <button class="btn btn-outline btn-sm" @click="goBack">
      Listeye Dön
    </button>
    <button class="btn btn-outline btn-sm" @click="downloadPDF">
      <IconDownload /> PDF İndir
    </button>
    <button class="btn btn-outline btn-sm" @click="sendEmail">
      <IconMail /> Mail Gönder
    </button>
    <button
      v-if="offer?.status === 'accepted'"
      class="btn btn-primary btn-sm"
      @click="convertToPolicy"
    >
      Poliçeye Dönüştür
    </button>
    <button v-else class="btn btn-primary btn-sm" @click="editOffer">
      Düzenle
    </button>
  </div>
</div>
```

## Ana Kolon - DetailCard Sections

### 1. Teminatlar
```html
<DetailCard title="Teminatlar">
  <template #action>
    <button class="btn btn-sm" @click="editCoverages">Düzenle</button>
  </template>
  
  <div v-if="!coverages?.length" class="card-empty">
    Teminat bilgisi girilmemiş.
  </div>
  <table v-else class="min-w-full">
    <thead class="bg-gray-50">
      <tr>
        <th class="table-header">Teminat</th>
        <th class="table-header text-right">Limit</th>
        <th class="table-header text-right">Prim</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-gray-100">
      <tr v-for="coverage in coverages" :key="coverage.name">
        <td class="table-cell">{{ coverage.coverage_name }}</td>
        <td class="table-cell text-right font-medium">{{ formatCurrency(coverage.limit) }}</td>
        <td class="table-cell text-right">{{ formatCurrency(coverage.premium) }}</td>
      </tr>
    </tbody>
  </table>
</DetailCard>
```

### 2. Dökümanlar
```html
<DetailCard title="Dökümanlar">
  <template #action>
    <button class="btn btn-sm">
      <IconUpload /> Yükle
    </button>
  </template>
  
  <div v-if="!documents?.length" class="card-empty">
    Döküman yüklenmemiş.
  </div>
  <div v-else class="divide-y divide-gray-100">
    <div
      v-for="doc in documents"
      :key="doc.name"
      class="flex items-center justify-between py-2.5"
    >
      <div class="flex items-center gap-2">
        <IconFileText class="w-4 h-4 text-gray-400" />
        <span class="text-sm text-gray-900">{{ doc.file_name }}</span>
      </div>
      <button class="btn-icon">
        <IconDownload class="w-4 h-4" />
      </button>
    </div>
  </div>
</DetailCard>
```

### 3. Aktivite Timeline
```html
<DetailCard title="Aktiviteler">
  <div v-if="!activities?.length" class="card-empty">
    Henüz aktivite kaydı yok.
  </div>
  <div v-else>
    <div
      v-for="activity in activities"
      :key="activity.name"
      class="timeline-item"
    >
      <div :class="['tl-dot', activity.is_important && 'tl-dot-active']" />
      <div>
        <p class="tl-text">{{ activity.description }}</p>
        <p class="tl-time">{{ formatDate(activity.creation) }} · {{ activity.owner }}</p>
      </div>
    </div>
  </div>
</DetailCard>
```

## Sidebar Sections

### 1. Müşteri Bilgisi
```html
<div>
  <p class="section-title">Müşteri</p>
  <div class="flex items-center gap-3 mb-3">
    <div class="avatar avatar-md avatar-blue">
      {{ initials(offer?.customer_name) }}
    </div>
    <div>
      <p class="text-sm font-medium text-gray-900">{{ offer?.customer_name }}</p>
      <button class="text-xs text-brand-600 hover:underline" @click="viewCustomer">
        Detayı Gör →
      </button>
    </div>
  </div>
</div>
```

### 2. Teklif Detayları
```html
<div>
  <p class="section-title">Teklif Detayları</p>
  <FieldGroup :fields="offerFields" :cols="1" />
</div>
```

```js
const offerFields = computed(() => [
  { label: 'Şirket', value: offer.value?.company_name, variant: 'default' },
  { label: 'Branş', value: offer.value?.branch, variant: 'default' },
  { label: 'Başlangıç', value: formatDate(offer.value?.start_date), variant: 'default' },
  { label: 'Bitiş', value: formatDate(offer.value?.end_date), variant: 'default' },
  { label: 'Geçerlilik', value: formatDate(offer.value?.valid_until), variant: 'accent' },
  { label: 'Prim', value: formatCurrency(offer.value?.premium), variant: 'default' },
  { label: 'Komisyon', value: formatCurrency(offer.value?.commission), variant: 'default' },
])
```

### 3. Kayıt Bilgileri
```html
<div>
  <p class="section-title">Kayıt Bilgileri</p>
  <FieldGroup :fields="recordFields" :cols="1" />
</div>
```

## Script Setup

```js
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import StatusBadge from '@/components/ui/StatusBadge.vue'
import HeroStrip from '@/components/ui/HeroStrip.vue'
import DetailCard from '@/components/ui/DetailCard.vue'
import FieldGroup from '@/components/ui/FieldGroup.vue'

const route = useRoute()
const router = useRouter()
const offerId = route.params.id

// Methods
function goBack() {
  router.push('/offers')
}

function downloadPDF() {
  // PDF download logic
}

function sendEmail() {
  // Email send logic
}

function convertToPolicy() {
  // Convert to policy logic
}

function editOffer() {
  // Edit logic
}

function viewCustomer() {
  router.push(`/customers/${offer.value?.customer}`)
}
```

## Kontrol Listesi

- [ ] `StatusBadge`, `HeroStrip`, `DetailCard`, `FieldGroup` import edilmiş
- [ ] Topbar action butonları teklif durumuna göre değişiyor
- [ ] Teminatlar tablosu gösteriliyor
- [ ] Dökümanlar listesi çalışıyor
- [ ] Timeline aktiviteleri gösteriliyor
- [ ] Müşteri linki çalışıyor
- [ ] PDF indirme ve mail gönderme butonları hazır
- [ ] "Poliçeye Dönüştür" butonu sadece accepted durumunda görünüyor

## Test Adımları

1. Bir teklif detayını aç
2. HeroStrip'teki bilgilerin doğru geldiğini kontrol et
3. Teminatlar tablosunu kontrol et
4. PDF indirme butonunu test et
5. Mail gönderme işlevini test et
6. Müşteri detayına git linkini test et
7. Kabul edilmiş teklifte "Poliçeye Dönüştür" butonunu test et
