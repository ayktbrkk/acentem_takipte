# Week 1 - Day 2: Poliçe Listesi Tasarım Sistemi Geçişi

## Hedef Dosya
`frontend/src/pages/PoliciesList.vue` (veya `PolicyBoard.vue`, `PoliceListesi.vue`)

## Görev
Liste görünümünü design system'e çevir. Filtreleme, sıralama ve arama işlevselliğini koru.

## Design Pattern: List View

```html
<div class="page-shell">
  <!-- Topbar -->
  <div class="detail-topbar">
    <div>
      <h1 class="detail-title">Poliçeler</h1>
      <p class="text-sm text-gray-500">{{ totalCount }} poliçe</p>
    </div>
    <div class="flex gap-2">
      <button class="btn btn-outline btn-sm">
        <IconFilter /> Filtrele
      </button>
      <button class="btn btn-outline btn-sm">
        <IconDownload /> Dışa Aktar
      </button>
      <button class="btn btn-primary btn-sm">
        + Yeni Poliçe
      </button>
    </div>
  </div>

  <!-- Summary Cards -->
  <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
    <div class="mini-metric">
      <p class="mini-metric-label">Toplam Poliçe</p>
      <p class="mini-metric-value">{{ summary.total }}</p>
    </div>
    <div class="mini-metric">
      <p class="mini-metric-label">Aktif</p>
      <p class="mini-metric-value text-brand-600">{{ summary.active }}</p>
    </div>
    <div class="mini-metric">
      <p class="mini-metric-label">Beklemede</p>
      <p class="mini-metric-value text-amber-600">{{ summary.pending }}</p>
    </div>
    <div class="mini-metric">
      <p class="mini-metric-label">Toplam Prim</p>
      <p class="mini-metric-value text-green-600">{{ formatCurrency(summary.totalPremium) }}</p>
    </div>
  </div>

  <!-- Filters Bar -->
  <div class="bg-white rounded-lg border border-gray-200 p-4 mb-4">
    <div class="flex flex-wrap items-center gap-3">
      <!-- Search -->
      <div class="flex-1 min-w-[200px]">
        <div class="relative">
          <input
            v-model="searchQuery"
            type="text"
            placeholder="Poliçe ara..."
            class="form-input pl-9"
          />
          <IconSearch class="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
        </div>
      </div>

      <!-- Status filter -->
      <div class="flex items-center gap-2">
        <span class="text-sm text-gray-600">Durum:</span>
        <button
          v-for="status in statusOptions"
          :key="status.value"
          :class="[
            'badge',
            activeStatus === status.value ? 'badge-blue' : 'badge-gray'
          ]"
          @click="activeStatus = status.value"
        >
          {{ status.label }}
          <span class="ml-1">{{ status.count }}</span>
        </button>
      </div>

      <!-- Branch filter -->
      <div class="flex items-center gap-2">
        <span class="text-sm text-gray-600">Branş:</span>
        <select v-model="selectedBranch" class="form-input w-40">
          <option value="">Tümü</option>
          <option v-for="branch in branches" :key="branch" :value="branch">
            {{ branch }}
          </option>
        </select>
      </div>

      <!-- Clear filters -->
      <button
        v-if="hasActiveFilters"
        class="btn btn-sm btn-outline"
        @click="clearFilters"
      >
        <IconX class="w-4 h-4" /> Temizle
      </button>
    </div>
  </div>

  <!-- Table -->
  <div class="bg-white rounded-lg border border-gray-200 overflow-hidden">
    <!-- Loading State -->
    <div v-if="isLoading" class="p-8 text-center">
      <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-brand-600"></div>
      <p class="mt-2 text-sm text-gray-500">Yükleniyor...</p>
    </div>

    <!-- Empty State -->
    <div v-else-if="!policies?.length" class="p-12 text-center">
      <div class="card-empty">
        <IconFileText class="w-12 h-12 mx-auto mb-3 text-gray-300" />
        <p class="text-gray-500">Poliçe bulunamadı</p>
        <button class="btn btn-sm btn-primary mt-4">
          + Yeni Poliçe Oluştur
        </button>
      </div>
    </div>

    <!-- Table Content -->
    <table v-else class="min-w-full divide-y divide-gray-200">
      <thead class="bg-gray-50">
        <tr>
          <th class="table-header">
            <input type="checkbox" @change="toggleSelectAll" />
          </th>
          <th class="table-header cursor-pointer" @click="sortBy('policy_no')">
            Poliçe No
            <IconChevronDown v-if="sortField === 'policy_no'" class="inline w-4 h-4" />
          </th>
          <th class="table-header cursor-pointer" @click="sortBy('customer_name')">
            Müşteri
            <IconChevronDown v-if="sortField === 'customer_name'" class="inline w-4 h-4" />
          </th>
          <th class="table-header">Branş</th>
          <th class="table-header">Şirket</th>
          <th class="table-header cursor-pointer" @click="sortBy('end_date')">
            Bitiş Tarihi
            <IconChevronDown v-if="sortField === 'end_date'" class="inline w-4 h-4" />
          </th>
          <th class="table-header">Durum</th>
          <th class="table-header text-right">Prim</th>
          <th class="table-header"></th>
        </tr>
      </thead>
      <tbody class="divide-y divide-gray-100 bg-white">
        <tr
          v-for="policy in policies"
          :key="policy.name"
          class="hover:bg-gray-50 cursor-pointer transition-colors"
          @click="navigateToDetail(policy)"
        >
          <td class="table-cell" @click.stop>
            <input
              type="checkbox"
              :checked="selectedPolicies.includes(policy.name)"
              @change="toggleSelect(policy.name)"
            />
          </td>
          <td class="table-cell">
            <span class="copy-tag">{{ policy.policy_no }}</span>
          </td>
          <td class="table-cell">
            <div class="flex items-center gap-2">
              <div class="avatar avatar-sm avatar-blue">
                {{ initials(policy.customer_name) }}
              </div>
              <p class="text-sm font-medium text-gray-900">{{ policy.customer_name }}</p>
            </div>
          </td>
          <td class="table-cell text-gray-600">{{ policy.branch }}</td>
          <td class="table-cell text-gray-600 text-sm">{{ policy.company }}</td>
          <td class="table-cell">
            <span :class="[
              'text-sm',
              isExpiringSoon(policy.end_date) ? 'text-red-600 font-medium' : 'text-gray-600'
            ]">
              {{ formatDate(policy.end_date) }}
            </span>
          </td>
          <td class="table-cell">
            <StatusBadge :status="policy.status?.toLowerCase()" />
          </td>
          <td class="table-cell text-right font-medium">
            {{ formatCurrency(policy.premium) }}
          </td>
          <td class="table-cell" @click.stop>
            <div class="flex gap-1">
              <button class="btn-icon" title="Görüntüle" @click="viewPolicy(policy)">
                <IconEye class="w-4 h-4" />
              </button>
              <button class="btn-icon" title="Düzenle" @click="editPolicy(policy)">
                <IconEdit class="w-4 h-4" />
              </button>
            </div>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Bulk Actions (shown when items selected) -->
    <div
      v-if="selectedPolicies.length > 0"
      class="px-4 py-3 bg-blue-50 border-t border-blue-200 flex items-center justify-between"
    >
      <p class="text-sm text-blue-900">
        {{ selectedPolicies.length }} poliçe seçildi
      </p>
      <div class="flex gap-2">
        <button class="btn btn-sm btn-outline">
          <IconDownload /> Dışa Aktar
        </button>
        <button class="btn btn-sm btn-outline">
          <IconMail /> Mail Gönder
        </button>
      </div>
    </div>

    <!-- Pagination -->
    <div class="px-4 py-3 border-t border-gray-200 flex items-center justify-between bg-white">
      <p class="text-sm text-gray-500">
        {{ paginationInfo }}
      </p>
      <div class="flex gap-2">
        <button
          class="btn btn-sm btn-outline"
          :disabled="!hasPrev"
          @click="prevPage"
        >
          Önceki
        </button>
        <div class="flex items-center gap-1">
          <button
            v-for="page in visiblePages"
            :key="page"
            :class="[
              'btn btn-sm',
              currentPage === page ? 'btn-primary' : 'btn-outline'
            ]"
            @click="goToPage(page)"
          >
            {{ page }}
          </button>
        </div>
        <button
          class="btn btn-sm btn-outline"
          :disabled="!hasNext"
          @click="nextPage"
        >
          Sonraki
        </button>
      </div>
    </div>
  </div>
</div>
```

## Script Setup

```js
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import StatusBadge from '@/components/ui/StatusBadge.vue'

const router = useRouter()

// State
const isLoading = ref(false)
const searchQuery = ref('')
const activeStatus = ref('')
const selectedBranch = ref('')
const selectedPolicies = ref([])
const sortField = ref('policy_no')
const sortDirection = ref('asc')
const currentPage = ref(1)
const pageSize = ref(20)

// Status options
const statusOptions = computed(() => [
  { label: 'Tümü', value: '', count: summary.value.total },
  { label: 'Aktif', value: 'active', count: summary.value.active },
  { label: 'Beklemede', value: 'waiting', count: summary.value.pending },
  { label: 'İptal', value: 'cancel', count: summary.value.cancelled },
])

// Computed
const hasActiveFilters = computed(() => {
  return searchQuery.value || activeStatus.value || selectedBranch.value
})

const paginationInfo = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value + 1
  const end = Math.min(currentPage.value * pageSize.value, totalCount.value)
  return `${start}-${end} / ${totalCount.value}`
})

const visiblePages = computed(() => {
  const total = Math.ceil(totalCount.value / pageSize.value)
  const current = currentPage.value
  const delta = 2
  const range = []
  
  for (let i = Math.max(2, current - delta); i <= Math.min(total - 1, current + delta); i++) {
    range.push(i)
  }
  
  if (current - delta > 2) range.unshift('...')
  if (current + delta < total - 1) range.push('...')
  
  range.unshift(1)
  if (total > 1) range.push(total)
  
  return range.filter(p => p !== '...' || range.indexOf(p) === range.lastIndexOf(p))
})

// Methods
function initials(name = '') {
  return name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase()
}

function formatDate(date) {
  if (!date) return '—'
  return new Date(date).toLocaleDateString('tr-TR')
}

function formatCurrency(amount) {
  if (!amount) return '—'
  return new Intl.NumberFormat('tr-TR', {
    style: 'currency',
    currency: 'TRY'
  }).format(amount)
}

function isExpiringSoon(endDate) {
  if (!endDate) return false
  const days = Math.ceil((new Date(endDate) - new Date()) / (1000 * 60 * 60 * 24))
  return days <= 30 && days >= 0
}

function sortBy(field) {
  if (sortField.value === field) {
    sortDirection.value = sortDirection.value === 'asc' ? 'desc' : 'asc'
  } else {
    sortField.value = field
    sortDirection.value = 'asc'
  }
  // Trigger re-fetch with new sort
}

function clearFilters() {
  searchQuery.value = ''
  activeStatus.value = ''
  selectedBranch.value = ''
}

function toggleSelectAll(event) {
  if (event.target.checked) {
    selectedPolicies.value = policies.value.map(p => p.name)
  } else {
    selectedPolicies.value = []
  }
}

function toggleSelect(policyName) {
  const index = selectedPolicies.value.indexOf(policyName)
  if (index > -1) {
    selectedPolicies.value.splice(index, 1)
  } else {
    selectedPolicies.value.push(policyName)
  }
}

function navigateToDetail(policy) {
  router.push(`/policies/${policy.name}`)
}

function prevPage() {
  if (currentPage.value > 1) currentPage.value--
}

function nextPage() {
  const totalPages = Math.ceil(totalCount.value / pageSize.value)
  if (currentPage.value < totalPages) currentPage.value++
}

function goToPage(page) {
  if (page !== '...') currentPage.value = page
}
```

## Yeni CSS Classes (design-system.css'e ekle)

```css
/* Table Styles */
.table-header {
  @apply px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider;
}

.table-cell {
  @apply px-4 py-3 text-sm;
}

/* Icon Button */
.btn-icon {
  @apply p-1.5 rounded-md text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors;
}

/* Spinner */
@keyframes spin {
  to { transform: rotate(360deg); }
}

.animate-spin {
  animation: spin 1s linear infinite;
}
```

## Kontrol Listesi

- [ ] `page-shell` wrapper eklendi
- [ ] `detail-topbar` ile header oluşturuldu
- [ ] Summary cards `mini-metric` kullanıyor
- [ ] Filter bar düzgün çalışıyor
- [ ] Tablo header'ları `table-header` kullanıyor
- [ ] StatusBadge doğru import edilmiş ve status değerleri normalize edilmiş
- [ ] Avatar initials gösteriliyor
- [ ] Hover efektleri çalışıyor
- [ ] Checkbox seçimleri çalışıyor
- [ ] Pagination butonları disabled state'i destekliyor
- [ ] Loading ve empty state'ler düzgün
- [ ] Sıralama (sort) işlevi çalışıyor
- [ ] Responsive görünüm mobile'da düzgün

## Test Adımları

1. Sayfayı aç ve tüm poliçelerin yüklendiğini doğrula
2. Filtreleri test et (durum, branş, arama)
3. Sıralama (sorting) fonksiyonunu test et
4. Checkbox seçimlerini test et
5. Pagination'ı test et
6. Bir poliçeye tıklayarak detay sayfasına git
7. Responsive görünümü mobil cihazda test et
