# Week 1 - Day 3: Teklif Listesi Tasarım Sistemi Geçişi

## Hedef Dosya
`frontend/src/pages/OffersList.vue` (veya `TekliflerListesi.vue`, `OffersBoard.vue`)

## Görev
Teklif listesini design system'e çevir. Poliçe listesi ile aynı pattern'i kullan, teklif-spesifik alanları ekle.

## Farklılıklar
- Status badge'ler: `'draft'`, `'sent'`, `'accepted'`, `'rejected'`, `'expired'`
- Ek kolonlar: Geçerlilik tarihi, Teklif durumu
- Quick actions: "Poliçeye Dönüştür", "PDF İndir", "Mail Gönder"

## Template Pattern

```html
<div class="page-shell">
  <!-- Topbar -->
  <div class="detail-topbar">
    <div>
      <h1 class="detail-title">Teklifler</h1>
      <p class="text-sm text-gray-500">{{ totalCount }} teklif</p>
    </div>
    <div class="flex gap-2">
      <button class="btn btn-outline btn-sm">
        <IconFilter /> Filtrele
      </button>
      <button class="btn btn-outline btn-sm">
        <IconDownload /> Dışa Aktar
      </button>
      <button class="btn btn-primary btn-sm">
        + Yeni Teklif
      </button>
    </div>
  </div>

  <!-- Summary Cards -->
  <div class="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
    <div class="mini-metric">
      <p class="mini-metric-label">Toplam Teklif</p>
      <p class="mini-metric-value">{{ summary.total }}</p>
    </div>
    <div class="mini-metric">
      <p class="mini-metric-label">Taslak</p>
      <p class="mini-metric-value text-gray-600">{{ summary.draft }}</p>
    </div>
    <div class="mini-metric">
      <p class="mini-metric-label">Gönderildi</p>
      <p class="mini-metric-value text-blue-600">{{ summary.sent }}</p>
    </div>
    <div class="mini-metric">
      <p class="mini-metric-label">Kabul Edildi</p>
      <p class="mini-metric-value text-green-600">{{ summary.accepted }}</p>
    </div>
    <div class="mini-metric">
      <p class="mini-metric-label">Dönüşüm Oranı</p>
      <p class="mini-metric-value text-brand-600">{{ conversionRate }}%</p>
    </div>
  </div>

  <!-- Filters Bar -->
  <div class="bg-white rounded-lg border border-gray-200 p-4 mb-4">
    <div class="flex flex-wrap items-center gap-3">
      <!-- Search -->
      <div class="flex-1 min-w-[200px]">
        <div class="relative">
          <input
            v-model="searchQuery"
            type="text"
            placeholder="Teklif ara..."
            class="form-input pl-9"
          />
          <IconSearch class="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
        </div>
      </div>

      <!-- Status filter -->
      <div class="flex items-center gap-2">
        <span class="text-sm text-gray-600">Durum:</span>
        <button
          v-for="status in statusOptions"
          :key="status.value"
          :class="[
            'badge',
            activeStatus === status.value ? 'badge-blue' : 'badge-gray'
          ]"
          @click="activeStatus = status.value"
        >
          {{ status.label }}
          <span class="ml-1">{{ status.count }}</span>
        </button>
      </div>

      <!-- Branch filter -->
      <div class="flex items-center gap-2">
        <span class="text-sm text-gray-600">Branş:</span>
        <select v-model="selectedBranch" class="form-input w-40">
          <option value="">Tümü</option>
          <option v-for="branch in branches" :key="branch" :value="branch">
            {{ branch }}
          </option>
        </select>
      </div>

      <!-- Date range filter -->
      <div class="flex items-center gap-2">
        <span class="text-sm text-gray-600">Tarih:</span>
        <select v-model="dateRange" class="form-input w-40">
          <option value="all">Tümü</option>
          <option value="today">Bugün</option>
          <option value="week">Bu Hafta</option>
          <option value="month">Bu Ay</option>
          <option value="expiring">Süresi Dolacak</option>
        </select>
      </div>

      <!-- Clear filters -->
      <button
        v-if="hasActiveFilters"
        class="btn btn-sm btn-outline"
        @click="clearFilters"
      >
        <IconX class="w-4 h-4" /> Temizle
      </button>
    </div>
  </div>

  <!-- Table -->
  <div class="bg-white rounded-lg border border-gray-200 overflow-hidden">
    <!-- Loading State -->
    <div v-if="isLoading" class="p-8 text-center">
      <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-brand-600"></div>
      <p class="mt-2 text-sm text-gray-500">Yükleniyor...</p>
    </div>

    <!-- Empty State -->
    <div v-else-if="!offers?.length" class="p-12 text-center">
      <div class="card-empty">
        <IconFileText class="w-12 h-12 mx-auto mb-3 text-gray-300" />
        <p class="text-gray-500">Teklif bulunamadı</p>
        <button class="btn btn-sm btn-primary mt-4">
          + Yeni Teklif Oluştur
        </button>
      </div>
    </div>

    <!-- Table Content -->
    <table v-else class="min-w-full divide-y divide-gray-200">
      <thead class="bg-gray-50">
        <tr>
          <th class="table-header">
            <input type="checkbox" @change="toggleSelectAll" />
          </th>
          <th class="table-header cursor-pointer" @click="sortBy('offer_no')">
            Teklif No
            <IconChevronDown v-if="sortField === 'offer_no'" class="inline w-4 h-4" />
          </th>
          <th class="table-header cursor-pointer" @click="sortBy('customer_name')">
            Müşteri
            <IconChevronDown v-if="sortField === 'customer_name'" class="inline w-4 h-4" />
          </th>
          <th class="table-header">Branş</th>
          <th class="table-header">Şirket</th>
          <th class="table-header cursor-pointer" @click="sortBy('valid_until')">
            Geçerlilik
            <IconChevronDown v-if="sortField === 'valid_until'" class="inline w-4 h-4" />
          </th>
          <th class="table-header cursor-pointer" @click="sortBy('created_at')">
            Oluşturulma
            <IconChevronDown v-if="sortField === 'created_at'" class="inline w-4 h-4" />
          </th>
          <th class="table-header">Durum</th>
          <th class="table-header text-right">Tutar</th>
          <th class="table-header"></th>
        </tr>
      </thead>
      <tbody class="divide-y divide-gray-100 bg-white">
        <tr
          v-for="offer in offers"
          :key="offer.name"
          class="hover:bg-gray-50 cursor-pointer transition-colors"
          @click="navigateToDetail(offer)"
        >
          <td class="table-cell" @click.stop>
            <input
              type="checkbox"
              :checked="selectedOffers.includes(offer.name)"
              @change="toggleSelect(offer.name)"
            />
          </td>
          <td class="table-cell">
            <span class="copy-tag">{{ offer.offer_no }}</span>
          </td>
          <td class="table-cell">
            <div class="flex items-center gap-2">
              <div class="avatar avatar-sm avatar-blue">
                {{ initials(offer.customer_name) }}
              </div>
              <p class="text-sm font-medium text-gray-900">{{ offer.customer_name }}</p>
            </div>
          </td>
          <td class="table-cell text-gray-600">{{ offer.branch }}</td>
          <td class="table-cell text-gray-600 text-sm">{{ offer.company }}</td>
          <td class="table-cell">
            <span :class="[
              'text-sm',
              isExpired(offer.valid_until) ? 'text-red-600 font-medium' : 
              isExpiringSoon(offer.valid_until) ? 'text-amber-600 font-medium' : 
              'text-gray-600'
            ]">
              {{ formatDate(offer.valid_until) }}
            </span>
          </td>
          <td class="table-cell text-gray-500 text-sm">
            {{ formatDate(offer.creation) }}
          </td>
          <td class="table-cell">
            <StatusBadge :status="offer.status?.toLowerCase()" />
          </td>
          <td class="table-cell text-right font-medium">
            {{ formatCurrency(offer.premium) }}
          </td>
          <td class="table-cell" @click.stop>
            <div class="flex gap-1">
              <button
                class="btn-icon"
                title="PDF İndir"
                @click="downloadPDF(offer)"
              >
                <IconDownload class="w-4 h-4" />
              </button>
              <button
                class="btn-icon"
                title="Mail Gönder"
                @click="sendEmail(offer)"
              >
                <IconMail class="w-4 h-4" />
              </button>
              <button
                v-if="offer.status === 'accepted'"
                class="btn-icon text-green-600"
                title="Poliçeye Dönüştür"
                @click="convertToPolicy(offer)"
              >
                <IconCheck class="w-4 h-4" />
              </button>
              <button
                class="btn-icon"
                title="Düzenle"
                @click="editOffer(offer)"
              >
                <IconEdit class="w-4 h-4" />
              </button>
            </div>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Bulk Actions -->
    <div
      v-if="selectedOffers.length > 0"
      class="px-4 py-3 bg-blue-50 border-t border-blue-200 flex items-center justify-between"
    >
      <p class="text-sm text-blue-900">
        {{ selectedOffers.length }} teklif seçildi
      </p>
      <div class="flex gap-2">
        <button class="btn btn-sm btn-outline">
          <IconDownload /> Toplu PDF İndir
        </button>
        <button class="btn btn-sm btn-outline">
          <IconMail /> Toplu Mail Gönder
        </button>
        <button class="btn btn-sm btn-outline text-red-600">
          <IconTrash /> Sil
        </button>
      </div>
    </div>

    <!-- Pagination -->
    <div class="px-4 py-3 border-t border-gray-200 flex items-center justify-between bg-white">
      <p class="text-sm text-gray-500">
        {{ paginationInfo }}
      </p>
      <div class="flex gap-2">
        <button
          class="btn btn-sm btn-outline"
          :disabled="!hasPrev"
          @click="prevPage"
        >
          Önceki
        </button>
        <div class="flex items-center gap-1">
          <button
            v-for="page in visiblePages"
            :key="page"
            :class="[
              'btn btn-sm',
              currentPage === page ? 'btn-primary' : 'btn-outline'
            ]"
            @click="goToPage(page)"
          >
            {{ page }}
          </button>
        </div>
        <button
          class="btn btn-sm btn-outline"
          :disabled="!hasNext"
          @click="nextPage"
        >
          Sonraki
        </button>
      </div>
    </div>
  </div>
</div>
```

## Script Setup

```js
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import StatusBadge from '@/components/ui/StatusBadge.vue'

const router = useRouter()

// State
const isLoading = ref(false)
const searchQuery = ref('')
const activeStatus = ref('')
const selectedBranch = ref('')
const dateRange = ref('all')
const selectedOffers = ref([])
const sortField = ref('creation')
const sortDirection = ref('desc')
const currentPage = ref(1)
const pageSize = ref(20)

// Status options
const statusOptions = computed(() => [
  { label: 'Tümü', value: '', count: summary.value.total },
  { label: 'Taslak', value: 'draft', count: summary.value.draft },
  { label: 'Gönderildi', value: 'sent', count: summary.value.sent },
  { label: 'Kabul', value: 'accepted', count: summary.value.accepted },
  { label: 'Red', value: 'rejected', count: summary.value.rejected },
  { label: 'Süresi Doldu', value: 'expired', count: summary.value.expired },
])

// Conversion rate
const conversionRate = computed(() => {
  if (!summary.value.total) return 0
  return ((summary.value.accepted / summary.value.total) * 100).toFixed(1)
})

// Computed
const hasActiveFilters = computed(() => {
  return searchQuery.value || activeStatus.value || selectedBranch.value || dateRange.value !== 'all'
})

const paginationInfo = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value + 1
  const end = Math.min(currentPage.value * pageSize.value, totalCount.value)
  return `${start}-${end} / ${totalCount.value}`
})

// Methods
function initials(name = '') {
  return name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase()
}

function formatDate(date) {
  if (!date) return '—'
  return new Date(date).toLocaleDateString('tr-TR')
}

function formatCurrency(amount) {
  if (!amount) return '—'
  return new Intl.NumberFormat('tr-TR', {
    style: 'currency',
    currency: 'TRY'
  }).format(amount)
}

function isExpired(validUntil) {
  if (!validUntil) return false
  return new Date(validUntil) < new Date()
}

function isExpiringSoon(validUntil) {
  if (!validUntil) return false
  const days = Math.ceil((new Date(validUntil) - new Date()) / (1000 * 60 * 60 * 24))
  return days <= 7 && days > 0
}

function clearFilters() {
  searchQuery.value = ''
  activeStatus.value = ''
  selectedBranch.value = ''
  dateRange.value = 'all'
}

function toggleSelectAll(event) {
  if (event.target.checked) {
    selectedOffers.value = offers.value.map(o => o.name)
  } else {
    selectedOffers.value = []
  }
}

function toggleSelect(offerName) {
  const index = selectedOffers.value.indexOf(offerName)
  if (index > -1) {
    selectedOffers.value.splice(index, 1)
  } else {
    selectedOffers.value.push(offerName)
  }
}

function navigateToDetail(offer) {
  router.push(`/offers/${offer.name}`)
}

function downloadPDF(offer) {
  // PDF download implementation
  console.log('Downloading PDF for:', offer.offer_no)
}

function sendEmail(offer) {
  // Email send implementation
  console.log('Sending email for:', offer.offer_no)
}

function convertToPolicy(offer) {
  // Convert to policy implementation
  console.log('Converting to policy:', offer.offer_no)
}

function editOffer(offer) {
  // Edit implementation
  console.log('Editing offer:', offer.offer_no)
}

function sortBy(field) {
  if (sortField.value === field) {
    sortDirection.value = sortDirection.value === 'asc' ? 'desc' : 'asc'
  } else {
    sortField.value = field
    sortDirection.value = 'asc'
  }
  // Trigger re-fetch with new sort
}

function prevPage() {
  if (currentPage.value > 1) currentPage.value--
}

function nextPage() {
  const totalPages = Math.ceil(totalCount.value / pageSize.value)
  if (currentPage.value < totalPages) currentPage.value++
}

function goToPage(page) {
  if (page !== '...') currentPage.value = page
}
```

## Kontrol Listesi

- [ ] `page-shell` wrapper eklendi
- [ ] `detail-topbar` ile header oluşturuldu
- [ ] Summary cards dönüşüm oranını gösteriyor
- [ ] Date range filter eklendi
- [ ] StatusBadge doğru import edilmiş
- [ ] Teklif-spesifik action butonları (PDF, Mail, Dönüştür) eklendi
- [ ] Expired ve expiring soon durumları renklendiriliyor
- [ ] Bulk actions (toplu işlemler) çalışıyor
- [ ] Icon'lar import edilmiş (IconDownload, IconMail, IconCheck, IconEdit)
- [ ] Responsive görünüm düzgün

## Test Adımları

1. Sayfayı aç ve tüm tekliflerin yüklendiğini doğrula
2. Filtreleri test et (durum, branş, tarih aralığı)
3. Sıralama işlevini test et
4. PDF indirme butonunu test et
5. Mail gönderme işlevini test et
6. Kabul edilmiş tekliflerde "Poliçeye Dönüştür" butonunu test et
7. Toplu işlemleri (bulk actions) test et
8. Geçerlilik tarihi yaklaşan/geçmiş tekliflerin renklendirmesini kontrol et
