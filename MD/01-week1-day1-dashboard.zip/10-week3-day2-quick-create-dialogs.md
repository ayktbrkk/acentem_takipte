# Week 3 - Day 2: Hızlı Oluşturma Dialog'ları

## Hedef Dosyalar
- `QuickCreateCustomer.vue`
- `QuickCreateOffer.vue`
- `QuickCreateClaim.vue`

## Compact Dialog Pattern

```html
<div class="dialog-overlay" @click.self="close">
  <div class="dialog-shell dialog-sm">
    <div class="dialog-header">
      <h3 class="dialog-title">Hızlı {{ entityType }} Oluştur</h3>
      <button class="btn-icon" @click="close"><IconX /></button>
    </div>

    <form @submit.prevent="handleSubmit" class="dialog-body">
      <div class="space-y-4">
        <div class="form-field">
          <label class="form-label required">{{ primaryField.label }}</label>
          <input v-model="form[primaryField.key]" type="text" class="form-input" required />
        </div>
      </div>
    </form>

    <div class="dialog-footer">
      <button type="button" class="btn btn-outline" @click="close">İptal</button>
      <button type="submit" class="btn btn-primary">Oluştur</button>
    </div>
  </div>
</div>
```

## CSS
```css
.dialog-overlay { @apply fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4; }
.dialog-shell { @apply bg-white rounded-lg shadow-2xl max-h-[90vh] overflow-hidden flex flex-col; }
.dialog-sm { @apply max-w-md w-full; }
.dialog-md { @apply max-w-2xl w-full; }
.dialog-header { @apply flex items-center justify-between px-6 py-4 border-b; }
.dialog-title { @apply text-lg font-semibold text-gray-900; }
.dialog-body { @apply p-6 overflow-y-auto flex-1; }
.dialog-footer { @apply px-6 py-4 bg-gray-50 border-t flex justify-end gap-3; }
```
