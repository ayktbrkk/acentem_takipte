# Week 1 - Day 4: Müşteri Listesi Tasarım Sistemi Geçişi

## Hedef Dosya
`frontend/src/pages/CustomersList.vue` (veya `MusterilerListesi.vue`, `CustomersBoard.vue`)

## Görev
Müşteri listesini avatar'lı card grid veya tablo görünümü olarak tasarla.

## İki Görünüm Seçeneği

### Opsiyon A: Card Grid (Önerilen - Müşteriler için daha uygun)

```html
<div class="page-shell">
  <!-- Topbar -->
  <div class="detail-topbar">
    <div>
      <h1 class="detail-title">Müşteriler</h1>
      <p class="text-sm text-gray-500">{{ totalCount }} müşteri</p>
    </div>
    <div class="flex gap-2">
      <button class="btn btn-outline btn-sm" @click="toggleView">
        <IconGrid v-if="viewMode === 'table'" />
        <IconList v-else />
        {{ viewMode === 'table' ? 'Kart' : 'Liste' }} Görünümü
      </button>
      <button class="btn btn-outline btn-sm">
        <IconFilter /> Filtrele
      </button>
      <button class="btn btn-outline btn-sm">
        <IconDownload /> Dışa Aktar
      </button>
      <button class="btn btn-primary btn-sm">
        + Yeni Müşteri
      </button>
    </div>
  </div>

  <!-- Summary Cards -->
  <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
    <div class="mini-metric">
      <p class="mini-metric-label">Toplam Müşteri</p>
      <p class="mini-metric-value">{{ summary.total }}</p>
    </div>
    <div class="mini-metric">
      <p class="mini-metric-label">Aktif</p>
      <p class="mini-metric-value text-brand-600">{{ summary.active }}</p>
    </div>
    <div class="mini-metric">
      <p class="mini-metric-label">Bireysel</p>
      <p class="mini-metric-value text-blue-600">{{ summary.individual }}</p>
    </div>
    <div class="mini-metric">
      <p class="mini-metric-label">Kurumsal</p>
      <p class="mini-metric-value text-purple-600">{{ summary.corporate }}</p>
    </div>
  </div>

  <!-- Filters Bar -->
  <div class="bg-white rounded-lg border border-gray-200 p-4 mb-4">
    <div class="flex flex-wrap items-center gap-3">
      <!-- Search -->
      <div class="flex-1 min-w-[250px]">
        <div class="relative">
          <input
            v-model="searchQuery"
            type="text"
            placeholder="Ad, telefon veya e-posta ile ara..."
            class="form-input pl-9"
          />
          <IconSearch class="absolute left-3 top-2.5 w-4 h-4 text-gray-400" />
        </div>
      </div>

      <!-- Customer Type filter -->
      <div class="flex items-center gap-2">
        <span class="text-sm text-gray-600">Tür:</span>
        <button
          v-for="type in customerTypes"
          :key="type.value"
          :class="[
            'badge',
            activeType === type.value ? 'badge-blue' : 'badge-gray'
          ]"
          @click="activeType = type.value"
        >
          {{ type.label }}
          <span class="ml-1">{{ type.count }}</span>
        </button>
      </div>

      <!-- Status filter -->
      <div class="flex items-center gap-2">
        <span class="text-sm text-gray-600">Durum:</span>
        <select v-model="activeStatus" class="form-input w-32">
          <option value="">Tümü</option>
          <option value="active">Aktif</option>
          <option value="inactive">Pasif</option>
        </select>
      </div>

      <!-- Clear filters -->
      <button
        v-if="hasActiveFilters"
        class="btn btn-sm btn-outline"
        @click="clearFilters"
      >
        <IconX class="w-4 h-4" /> Temizle
      </button>
    </div>
  </div>

  <!-- Loading State -->
  <div v-if="isLoading" class="flex justify-center py-12">
    <div class="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-brand-600"></div>
  </div>

  <!-- Empty State -->
  <div v-else-if="!customers?.length" class="bg-white rounded-lg border border-gray-200 p-12">
    <div class="card-empty">
      <IconUsers class="w-12 h-12 mx-auto mb-3 text-gray-300" />
      <p class="text-gray-500">Müşteri bulunamadı</p>
      <button class="btn btn-sm btn-primary mt-4">
        + Yeni Müşteri Oluştur
      </button>
    </div>
  </div>

  <!-- Card Grid View -->
  <div v-else-if="viewMode === 'card'" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
    <div
      v-for="customer in customers"
      :key="customer.name"
      class="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-md transition-shadow cursor-pointer"
      @click="navigateToDetail(customer)"
    >
      <div class="flex items-start gap-3">
        <!-- Avatar -->
        <div :class="[
          'avatar avatar-lg',
          customer.customer_type === 'Individual' ? 'avatar-blue' : 'avatar-purple'
        ]">
          {{ initials(customer.customer_name) }}
        </div>

        <!-- Content -->
        <div class="flex-1 min-w-0">
          <!-- Header -->
          <div class="flex items-start justify-between mb-1">
            <h3 class="text-sm font-semibold text-gray-900 truncate">
              {{ customer.customer_name }}
            </h3>
            <StatusBadge :status="customer.enabled ? 'active' : 'disabled'" />
          </div>
          
          <p class="text-xs text-gray-500 mb-3">
            <span :class="[
              'inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium',
              customer.customer_type === 'Individual' 
                ? 'bg-blue-50 text-blue-700' 
                : 'bg-purple-50 text-purple-700'
            ]">
              {{ customer.customer_type === 'Individual' ? 'Bireysel' : 'Kurumsal' }}
            </span>
          </p>

          <!-- Contact Info -->
          <div class="space-y-1.5 mb-3">
            <div v-if="customer.mobile_no" class="flex items-center gap-1.5 text-xs text-gray-600">
              <IconPhone class="w-3.5 h-3.5 flex-shrink-0" />
              <span class="truncate">{{ customer.mobile_no }}</span>
            </div>
            <div v-if="customer.email_id" class="flex items-center gap-1.5 text-xs text-gray-600">
              <IconMail class="w-3.5 h-3.5 flex-shrink-0" />
              <span class="truncate">{{ customer.email_id }}</span>
            </div>
            <div v-if="customer.tax_id" class="flex items-center gap-1.5 text-xs text-gray-600">
              <IconHash class="w-3.5 h-3.5 flex-shrink-0" />
              <span class="truncate">{{ customer.tax_id }}</span>
            </div>
          </div>

          <!-- Footer -->
          <div class="flex items-center justify-between pt-3 border-t border-gray-100">
            <span class="copy-tag text-xs">{{ customer.name }}</span>
            <div class="flex items-center gap-2 text-xs text-gray-500">
              <IconFileText class="w-3.5 h-3.5" />
              {{ customer.policy_count || 0 }} poliçe
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Table View -->
  <div v-else class="bg-white rounded-lg border border-gray-200 overflow-hidden">
    <table class="min-w-full divide-y divide-gray-200">
      <thead class="bg-gray-50">
        <tr>
          <th class="table-header">
            <input type="checkbox" @change="toggleSelectAll" />
          </th>
          <th class="table-header cursor-pointer" @click="sortBy('customer_name')">
            Müşteri
            <IconChevronDown v-if="sortField === 'customer_name'" class="inline w-4 h-4" />
          </th>
          <th class="table-header">Tür</th>
          <th class="table-header">İletişim</th>
          <th class="table-header">TC/VKN</th>
          <th class="table-header text-center">Poliçe</th>
          <th class="table-header">Durum</th>
          <th class="table-header cursor-pointer" @click="sortBy('creation')">
            Kayıt Tarihi
            <IconChevronDown v-if="sortField === 'creation'" class="inline w-4 h-4" />
          </th>
          <th class="table-header"></th>
        </tr>
      </thead>
      <tbody class="divide-y divide-gray-100 bg-white">
        <tr
          v-for="customer in customers"
          :key="customer.name"
          class="hover:bg-gray-50 cursor-pointer transition-colors"
          @click="navigateToDetail(customer)"
        >
          <td class="table-cell" @click.stop>
            <input
              type="checkbox"
              :checked="selectedCustomers.includes(customer.name)"
              @change="toggleSelect(customer.name)"
            />
          </td>
          <td class="table-cell">
            <div class="flex items-center gap-2">
              <div :class="[
                'avatar avatar-sm',
                customer.customer_type === 'Individual' ? 'avatar-blue' : 'avatar-purple'
              ]">
                {{ initials(customer.customer_name) }}
              </div>
              <div>
                <p class="text-sm font-medium text-gray-900">{{ customer.customer_name }}</p>
                <p class="text-xs text-gray-400">{{ customer.name }}</p>
              </div>
            </div>
          </td>
          <td class="table-cell">
            <span :class="[
              'inline-flex items-center px-2 py-0.5 rounded text-xs font-medium',
              customer.customer_type === 'Individual' 
                ? 'bg-blue-50 text-blue-700' 
                : 'bg-purple-50 text-purple-700'
            ]">
              {{ customer.customer_type === 'Individual' ? 'Bireysel' : 'Kurumsal' }}
            </span>
          </td>
          <td class="table-cell">
            <div class="text-sm">
              <p class="text-gray-900">{{ customer.mobile_no || '—' }}</p>
              <p class="text-gray-400 text-xs">{{ customer.email_id || '—' }}</p>
            </div>
          </td>
          <td class="table-cell text-gray-600 font-mono text-sm">
            {{ customer.tax_id || customer.tc_no || '—' }}
          </td>
          <td class="table-cell text-center">
            <span class="inline-flex items-center justify-center w-7 h-7 rounded-full bg-brand-50 text-brand-600 text-xs font-semibold">
              {{ customer.policy_count || 0 }}
            </span>
          </td>
          <td class="table-cell">
            <StatusBadge :status="customer.enabled ? 'active' : 'disabled'" />
          </td>
          <td class="table-cell text-gray-500 text-sm">
            {{ formatDate(customer.creation) }}
          </td>
          <td class="table-cell" @click.stop>
            <div class="flex gap-1">
              <button class="btn-icon" title="Görüntüle" @click="viewCustomer(customer)">
                <IconEye class="w-4 h-4" />
              </button>
              <button class="btn-icon" title="Düzenle" @click="editCustomer(customer)">
                <IconEdit class="w-4 h-4" />
              </button>
            </div>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Bulk Actions -->
    <div
      v-if="selectedCustomers.length > 0"
      class="px-4 py-3 bg-blue-50 border-t border-blue-200 flex items-center justify-between"
    >
      <p class="text-sm text-blue-900">
        {{ selectedCustomers.length }} müşteri seçildi
      </p>
      <div class="flex gap-2">
        <button class="btn btn-sm btn-outline">
          <IconDownload /> Dışa Aktar
        </button>
        <button class="btn btn-sm btn-outline">
          <IconMail /> Toplu Mail
        </button>
      </div>
    </div>

    <!-- Pagination -->
    <div class="px-4 py-3 border-t border-gray-200 flex items-center justify-between bg-white">
      <p class="text-sm text-gray-500">
        {{ paginationInfo }}
      </p>
      <div class="flex gap-2">
        <button
          class="btn btn-sm btn-outline"
          :disabled="!hasPrev"
          @click="prevPage"
        >
          Önceki
        </button>
        <button
          class="btn btn-sm btn-outline"
          :disabled="!hasNext"
          @click="nextPage"
        >
          Sonraki
        </button>
      </div>
    </div>
  </div>
</div>
```

## Script Setup

```js
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import StatusBadge from '@/components/ui/StatusBadge.vue'

const router = useRouter()

// State
const isLoading = ref(false)
const viewMode = ref('card') // 'card' or 'table'
const searchQuery = ref('')
const activeType = ref('')
const activeStatus = ref('')
const selectedCustomers = ref([])
const sortField = ref('customer_name')
const sortDirection = ref('asc')
const currentPage = ref(1)
const pageSize = ref(18) // 18 for grid (3x6), adjust for table

// Customer type options
const customerTypes = computed(() => [
  { label: 'Tümü', value: '', count: summary.value.total },
  { label: 'Bireysel', value: 'Individual', count: summary.value.individual },
  { label: 'Kurumsal', value: 'Corporate', count: summary.value.corporate },
])

// Computed
const hasActiveFilters = computed(() => {
  return searchQuery.value || activeType.value || activeStatus.value
})

const paginationInfo = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value + 1
  const end = Math.min(currentPage.value * pageSize.value, totalCount.value)
  return `${start}-${end} / ${totalCount.value}`
})

const hasPrev = computed(() => currentPage.value > 1)
const hasNext = computed(() => {
  const totalPages = Math.ceil(totalCount.value / pageSize.value)
  return currentPage.value < totalPages
})

// Methods
function initials(name = '') {
  return name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase()
}

function formatDate(date) {
  if (!date) return '—'
  return new Date(date).toLocaleDateString('tr-TR')
}

function toggleView() {
  viewMode.value = viewMode.value === 'card' ? 'table' : 'card'
  // Adjust pageSize based on view
  pageSize.value = viewMode.value === 'card' ? 18 : 20
}

function clearFilters() {
  searchQuery.value = ''
  activeType.value = ''
  activeStatus.value = ''
}

function toggleSelectAll(event) {
  if (event.target.checked) {
    selectedCustomers.value = customers.value.map(c => c.name)
  } else {
    selectedCustomers.value = []
  }
}

function toggleSelect(customerName) {
  const index = selectedCustomers.value.indexOf(customerName)
  if (index > -1) {
    selectedCustomers.value.splice(index, 1)
  } else {
    selectedCustomers.value.push(customerName)
  }
}

function navigateToDetail(customer) {
  router.push(`/customers/${customer.name}`)
}

function viewCustomer(customer) {
  navigateToDetail(customer)
}

function editCustomer(customer) {
  // Edit implementation
  console.log('Editing customer:', customer.customer_name)
}

function sortBy(field) {
  if (sortField.value === field) {
    sortDirection.value = sortDirection.value === 'asc' ? 'desc' : 'asc'
  } else {
    sortField.value = field
    sortDirection.value = 'asc'
  }
  // Trigger re-fetch
}

function prevPage() {
  if (hasPrev.value) currentPage.value--
}

function nextPage() {
  if (hasNext.value) currentPage.value++
}
```

## Kontrol Listesi

- [ ] `page-shell` wrapper eklendi
- [ ] `detail-topbar` ile header oluşturuldu
- [ ] View toggle (Kart/Liste) butonu eklendi
- [ ] Card grid görünümü responsive
- [ ] Avatar'lar müşteri tipine göre renklendiriliyor (Bireysel: mavi, Kurumsal: mor)
- [ ] StatusBadge doğru import edilmiş
- [ ] İletişim bilgileri (telefon, mail) gösteriliyor
- [ ] Table view alternatif olarak çalışıyor
- [ ] Poliçe sayısı gösteriliyor
- [ ] Filtreleme (tür, durum, arama) çalışıyor
- [ ] Icon'lar import edilmiş (IconPhone, IconMail, IconHash, IconUsers, IconGrid, IconList)

## Test Adımları

1. Sayfayı aç ve müşterilerin yüklendiğini doğrula
2. Kart görünümünde müşterileri kontrol et
3. Liste görünümüne geç ve tablo formatını test et
4. Filtreleri test et (tür, durum, arama)
5. Bir müşteriye tıklayarak detay sayfasına git
6. Avatar'ların doğru renkte olduğunu kontrol et
7. Responsive görünümü mobile'da test et
8. Bulk selection test et
