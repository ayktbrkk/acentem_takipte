# Week 3 - Day 4: İçe/Dışa Aktarma Ekranları

## Hedef Dosyalar
`ImportData.vue`, `ExportData.vue`

## Import Screen Pattern

```html
<div class="page-shell">
  <div class="detail-topbar">
    <h1 class="detail-title">Veri İçe Aktarma</h1>
  </div>

  <DetailCard title="1. Dosya Seç">
    <div class="form-field">
      <label class="form-label">Excel Dosyası</label>
      <input type="file" accept=".xlsx,.xls,.csv" @change="handleFileSelect" class="form-input" />
    </div>
  </DetailCard>

  <DetailCard title="2. Eşleştirme">
    <table class="min-w-full">
      <thead><tr>
        <th class="table-header">Excel Kolonu</th>
        <th class="table-header">Sistem Alanı</th>
      </tr></thead>
      <tbody>
        <tr v-for="col in columns" :key="col">
          <td class="table-cell">{{ col }}</td>
          <td class="table-cell">
            <select class="form-input"><option>...</option></select>
          </td>
        </tr>
      </tbody>
    </table>
  </DetailCard>

  <DetailCard title="3. Önizleme">
    <div class="overflow-x-auto">
      <table class="min-w-full text-sm">...</table>
    </div>
  </DetailCard>

  <div class="flex justify-end gap-2">
    <button class="btn btn-outline">İptal</button>
    <button class="btn btn-primary">İçe Aktar</button>
  </div>
</div>
```
