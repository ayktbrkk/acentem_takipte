# Week 4 - Day 4: Son Temizlik ve Optimizasyon

## Görevler

### 1. Unused Frappe UI Components
```bash
# Kullanılmayan Frappe UI importlarını bul ve kaldır
grep -r "from 'frappe-ui'" frontend/src/ | grep -v node_modules
```

### 2. CSS Cleanup
- Kullanılmayan eski CSS class'ları kaldır
- Duplicate CSS tanımlarını birleştir
- CSS dosyasını optimize et

### 3. Consistency Check
Tüm sayfalarda:
- [ ] `page-shell` wrapper var mı?
- [ ] `detail-topbar` kullanılıyor mu?
- [ ] `StatusBadge` import edilmiş mi?
- [ ] Butonlar `btn` class'ları kullanıyor mu?
- [ ] Renkler token'ları kullanıyor mu?

### 4. Performance
- [ ] Lazy load komponentleri
- [ ] Image optimization
- [ ] Code splitting

### 5. Accessibility
- [ ] ARIA labels
- [ ] Keyboard navigation
- [ ] Focus states

### 6. Documentation
- Component usage guide güncelle
- Design system dokümantasyonu tamamla

### 7. Final Test
- [ ] Tüm sayfaları test et
- [ ] Mobile responsive kontrol
- [ ] Cross-browser test
- [ ] Performance audit (Lighthouse)

### 8. Audit Script
```bash
node scripts/audit-design-system.js
```
Tüm sayfaların migrated olduğunu doğrula.
