# Week 4 - Day 2: Yenileme Tahtası (Kanban)

## Hedef Dosya
`frontend/src/pages/RenewalsBoard.vue`

## Kanban Board Pattern

```html
<div class="page-shell">
  <div class="detail-topbar">
    <h1 class="detail-title">Yenileme Tahtası</h1>
  </div>

  <div class="flex gap-4 overflow-x-auto pb-4">
    <div v-for="column in columns" :key="column.id" class="kanban-column">
      <div class="kanban-header">
        <h3 class="kanban-title">{{ column.title }}</h3>
        <span class="badge badge-gray">{{ column.items.length }}</span>
      </div>

      <div class="kanban-body">
        <div v-for="item in column.items" :key="item.name" class="kanban-card">
          <div class="flex items-start justify-between mb-2">
            <p class="text-sm font-medium">{{ item.customer_name }}</p>
            <span :class="priorityBadge(item.priority)">{{ item.priority }}</span>
          </div>
          <p class="text-xs text-gray-600">{{ item.policy_branch }} · {{ formatCurrency(item.premium) }}</p>
          <div class="flex items-center justify-between mt-2">
            <span class="text-xs text-gray-400">{{ formatDate(item.due_date) }}</span>
            <div class="avatar avatar-xs avatar-blue">{{ initials(item.assigned_to) }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
```

## Kanban CSS
```css
.kanban-column { @apply flex-shrink-0 w-80 bg-gray-50 rounded-lg; }
.kanban-header { @apply flex items-center justify-between px-4 py-3 border-b; }
.kanban-title { @apply text-sm font-semibold text-gray-700; }
.kanban-body { @apply p-3 space-y-3 max-h-[calc(100vh-16rem)] overflow-y-auto; }
.kanban-card { @apply bg-white rounded-lg border p-3 hover:shadow-md transition cursor-pointer; }
```
