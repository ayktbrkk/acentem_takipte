# Week 4 - Day 3: Analitik Dashboard'lar

## Hedef Dosyalar
Advanced analytics pages

## Pattern
Dashboard (Week 1 Day 1) pattern'ini kullan.
Ekstra özellikler:
- Daha fazla grafik
- Karşılaştırmalı görünümler
- Trend analizleri
- Filter sidebar

```html
<div class="page-shell">
  <div class="detail-topbar">
    <h1 class="detail-title">Analitik Dashboard</h1>
    <div class="flex gap-2">
      <select class="form-input w-40">
        <option>Bu Ay</option>
        <option>Bu Yıl</option>
      </select>
      <button class="btn btn-outline btn-sm"><IconRefresh /></button>
    </div>
  </div>

  <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
    <!-- 3/4 width charts -->
    <div class="lg:col-span-3 space-y-6">
      <DetailCard title="Prim Trendi">
        <div class="chart-container h-96">...</div>
      </DetailCard>
    </div>

    <!-- 1/4 width filters & summary -->
    <div class="space-y-4">
      <DetailCard title="Filtreler">...</DetailCard>
      <DetailCard title="Özet">...</DetailCard>
    </div>
  </div>
</div>
```
